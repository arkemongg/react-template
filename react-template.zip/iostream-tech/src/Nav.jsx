import { Outlet } from 'react-router-dom'
import './Nav.css'

const Navigation = () => {
    return (
        <>
            <div className="max-w-[1390px] m-auto">
            <div className="navbar outline sticky">
                <a className="btn btn-ghost normal-case text-xl">daisyUI</a>
            </div>
            <div className='min-h-[150vh]'>
                <Outlet />
            </div>
            </div>
        </>
    )
}

export default Navigation